<?php 
/*
~~~~~~~~ VG ~~~~~~~

Copyright (C) 2007 Madars Anziķis

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Versija: 0.2.2
Modificēts: 2007.12.23.
Mail: mad182@gmail.com
Info: http://w3.ppf.lu.lv/mad182/
*/

######### KONFIGURĀCIJA #################################

$komenti = "komentari_paraugs.txt"; //fails, kurā glabāsies komentāri (tam jābūt rakstāmam - CHMOD 777)
$maxtgar = "2048"; //maksimālais komentāra garums (simbolos)
$maxngar = "32"; //maksimālais nika garums
$nosaukums = "ViesuGrāmata 0.2.2"; //lapas nosaukums
$sakt = "1"; //0 - jaunākie ieraksti apakšā, 1 - jaunākie ieraksti augšā, 2 - jaukta secība
$navkom = "Pagaidām viesugrāmatā nav ierakstu. Tev ir visas iespējas būt pirmajam!"; //ko rādīt, ja nav komentāru
$klapa = "6"; //komentāru skaits vienā lapā
$stils = "zils.css"; //CSS faila nosaukums (Noklusēti - "zils.css" vai "melns.css")
$ikona = "bildes/fav.gif"; //favikona (16x16px attēls)
$captcha = "1"; //captcha (attēla ar kodu) aizsardzība. 0 - izslēgts, 1 - ieslēgts
$nikalaiks = time()+31556926; //cik ilgi glabāt lietotāja niku un url cepumā, 31556926 = 1gads
$detrkonf = "1"; //vai piedāvāt iespēju detranslitēt tekstu, 1 - ieslēgts, 0 - izslēgts
error_reporting(0); //kļūdu paziņojumu līmenis, 0 - izslēgts (lietošanai), E_ALL - visas kļūdas (testēšanai)

//ip adreses ar bloķētu iespēju komentēt ('ip','ip2','ip3',...), ip adreses tiek saglabātas failā, kurā glabājas komentāri
$banotie = array('123.45.67.89',
				'12.34.56.78',
				'99.99.99.99');

#########################################################

//tālāk labo tikai tad, ja tev ir nojausma ko un kāpēc dari. Izskats tiek mainīts ar CSS palīdzību.

$versija = "0.2.2";

//captcha
if ($captcha == "1") {
	session_start();
	if (isset($_POST['secure'])) {
		$secure = strtoupper(trim(strip_tags($_POST['secure'])));
	} else {
		$secure = "";
	}
	$match = $_SESSION['captcha'];
}

//f-ja, kas smaidiņu simbolus aizstāj ar attēliem
function smaidi($navsmaida) {
	//izmantojamie smaidiņi. Var pievienot papildus tik, cik vēlas 
	$kodi = array(':)',
				';)',
				':D',
				':P',
				':(',
				'8)',
				'???',
				'!!!',
				':|');
	//masīvs ar simboliem atbisltošajiem attēliem
	$bildes = array('<img src="bildes/smaidini/smaida.gif" width="15" height="15" border="0" alt=":)" />',
				'<img src="bildes/smaidini/miedz.gif" width="15" height="15" border="0" alt=";)" />',
				'<img src="bildes/smaidini/reec.gif" width="15" height="15" border="0" alt=":D" />',
				'<img src="bildes/smaidini/mele.gif" width="15" height="15" border="0" alt=":P" />',
				'<img src="bildes/smaidini/bedigs.gif" width="15" height="15" border="0" alt=":(" />',
				'<img src="bildes/smaidini/kruts.gif" width="15" height="15" border="0" alt="8)" />',
				'<img src="bildes/smaidini/jautajums.gif" width="15" height="15" border="0" alt="???" />',
				'<img src="bildes/smaidini/izsaukums.gif" width="15" height="15" border="0" alt="!!!" />',
				'<img src="bildes/smaidini/vienalga.gif" width="15" height="15" border="0" alt=":|" />');
	//aizvieto simbolus ar bildēm
	$smaidigs = str_replace($kodi, $bildes, $navsmaida);
	return $smaidigs;
}

//f-ja, kas translita simbolus aizstāj ar latviešu spec. zīmēm
function detrans($teksts) {
	//simboli translitā
	$translits = array("aa", "Aa", "AA",
				"ch", "Ch", "CH",
				"ee", "Ee", "EE",
				"gj", "Gj", "GJ",
				"ii", "Ii", "II",
				"kj", "Kj", "KJ",
				"lj", "Lj", "LJ",
				"nj", "Nj", "NJ",
				"rj", "Rj", "RJ",
				"sh", "Sh", "SH",
				"uu", "Uu", "UU",
				"zh", "Zh", "ZH");
	//latviešu speciālie simboli
	$latviesu = array("ā", "Ā", "Ā",
				"č", "Č", "Č",
				"ē", "Ē", "Ē",
				"ģ", "Ģ", "Ģ",
				"ī", "Ī", "Ī",
				"ķ", "Ķ", "Ķ",
				"ļ", "Ļ", "Ļ",
				"ņ", "Ņ", "Ņ",
				"ŗ", "Ŗ", "Ŗ",
				"š", "Š", "Š",
				"ū", "Ū", "Ū",
				"ž", "Ž", "Ž");
	//aizstāj translita masīvu ar latviešu masīvu 
	$teksts = str_replace($translits, $latviesu, $teksts);
	return $teksts; //atgriež tekstu
}

//f-ja, kas bb koda tagus aizstāj ar html
function bb2html($text) {
	//norāda, kādi BB koda tagi izmantojami
	$bbcode = array("<", ">",
				"[list]", "[*]", "[/list]", 
				"[b]", "[/b]", 
				"[u]", "[/u]", 
				"[i]", "[/i]",
				'[color=\"', "[/color]",
				'[size=\"', "[/size]",
				'[url=\"', "[/url]",
				"[mail=\"", "[/mail]",
				"[code]", "[/code]",
				"[quote]", "[/quote]",
				"[q]", "[/q]",
				'"]');
	//atbilsotšie html tagi
	$htmlcode = array("&lt;", "&gt;",
				"<ul>", "<li>", "</ul>", 
				"<b>", "</b>", 
				"<u>", "</u>", 
				"<i>", "</i>",
				"<span style=\"color:", "</span>",
				"<span style=\"font-size:", "</span>",
				'<a href="', "</a>",
				"<a href=\"mailto:", "</a>",
				"<code>", "</code>",
				"<blockquote>", "</blockquote>",
				"<blockquote>", "</blockquote>",
				'">');
	//pārveido bb kodu par html
	$newtext = str_replace($bbcode, $htmlcode, $text);
	//pārveido jaunās līnijas pārlūkam saprotamā veidā un aizvāc \n un \r simbolus
	$newtext = str_replace("\n","<br />",$newtext);
	$newtext = str_replace("\r","",$newtext);
	//izvairās no nevēlamiem simboliem drošības dēļ
	$newtext = str_replace("|*|","#",$newtext);
	return $newtext;
}

//dabū klienta IP adresi
function dabutip() {
	if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	  $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} elseif (isset($_SERVER['HTTP_VIA'])) {
		$ip = $_SERVER['HTTP_VIA'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}

//pārbauda, vai IP nav starp bloķētajām
function parbauditip($ip,$banotie) {
	if (in_array($ip,$banotie)) {
		die("Tev nav atļauts komentēt šo viesugrāmatu!");
	}
}

//uzzinam, kāda būs veicamā darbība
if (isset($_GET['darbiba'])) { 
	$darbiba = $_GET['darbiba']; 
} else {
	$darbiba = "";
}

//čekojam, vai mēģina pievienot komentāru
if ($darbiba == "komentars") {
	//ja captcha ir izslēgta vai ievadīts pareizs kods, ļauj pievienot komentāru
	if ($captcha != "1" or $secure == $match) {
		//dabujam un apstrādājam saņemto informāciju
		$ip = dabutip();
		//pārbauda, vai lietotājs nav starp bloķētajiem
		parbauditip($ip,$banotie);
		$datums = date("d M Y h:i a");
		$niks = htmlspecialchars($_POST["niks"]);
		$niks = str_replace("|*|","#",$niks);
		$url = htmlspecialchars($_POST["url"]);
		$url = str_replace("http://http://","http://",$url);
		$url = str_replace("|*|","#",$url);
		$teksts = bb2html($_POST["teksts"]);
		$teksts = stripslashes($teksts);
		$teksts = wordwrap("$teksts", 50, " ", " ");
		//ja nepieciešams, novac translitu
		if ($detrkonf == 1 && isset($_POST["detrans"])) {
			$teksts = detrans($teksts);
		}
		//saīsina ievadītos datus līdz atļautam garumam
		$url = substr($url, 0, 256);
		$teksts = substr($teksts, 0, $maxtgar);
		$niks = substr($niks, 0, $maxngar);
		//atver datu failu rakstīšanai
		$fails = fopen("$komenti", "a");
		if (!$fails) {
			die("<b>Ķļūda!</b><br />Nesanāca atvērt failu.");
		}
		//ieraksta jaunos datus
		fwrite($fails,"$niks|*|$teksts|*|$datums|*|$ip|*|$url|*||*|\n");
		//aizver failu
		fclose($fails);
		//ierakstam niku un url cepumā, lai citreiz nav jāatkārto
		setcookie("niks",$niks,$nikalaiks);
		setcookie("url",$url,$nikalaiks);
	//ja nepareizs kods
	} else {
		die("Tu ievadīji nepareizu kodu!");
	}
}

//sakārtojam adresi pēc komentāra pievienošanas
if (substr($_SERVER['REQUEST_URI'],-18)=='?darbiba=komentars') {
	$adrese = str_replace('?darbiba=komentars','',$_SERVER['REQUEST_URI']);
	//pārmet atpakaļ uz sākuma adresi
	header('Location: '.$adrese);
}
?>
<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="lv" lang="lv">

<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="lv" />
<title><?php echo "$nosaukums "; ?></title>
<!-- Izveidots izmantojot VG <?php echo "$versija"; ?>, kas brīvi pieejama http://w3.ppf.lu.lv/mad182/ -->
<link rel="shortcut icon" href="<?php echo "$ikona"; ?>" />
<link href="<?php echo "$stils"; ?>" rel="stylesheet" type="text/css" />
<script language="JavaScript" type="text/javascript">
<!--
function ParbauditFormu(Form)
{
	if (Form.niks.value == "") {
		alert( "Kā tevi dēvēt?" );
		Form.niks.focus();
		    return false;
	}
	if (Form.teksts.value == "") {
		alert( "Kur tad teksts?" );
		Form.teksts.focus();
		return false;
	}
	return true;
}

function IeliktSmaidu(Smaids)
{
	document.komentars.teksts.value += Smaids+" ";
	document.komentars.teksts.focus();
}
//-->
</script>
</head>

<body>
<table align="center" width="600">
	<tr>
		<th>Komentāri</th>
	</tr>
<?php
//čekojam vai ir datu fails, ja ir, dabūjam datus no tā
if (file_exists($komenti)) {
	$f = file("$komenti");
	//noskaidro, kādā secībā jārāda komentārus
	if ($sakt == "1") {
		$f = array_reverse($f);
	} elseif ($sakt == "2") {
		shuffle($f);
	}
	$cik = count($f);
	//izrēķina, cik pavisam lapas
	$lapas=ceil($cik/$klapa);
	//uzzina, kuru lapu jārāda
	if (!isset($_GET['komentarulapa'])) {
		$komentarulapa = 1;
	} else {
		$komentarulapa = $_GET['komentarulapa'];
	}
	//izrēķina, no kura komentāra jāsāk rādīt
	$no=$komentarulapa*$klapa-$klapa;
	$lidz=$no+$klapa;
	for ($i=$no; $i<$lidz; $i++) {
		//sadalām rindu saprotamos mainīgajos
		//2 vietas datu failā un mainīgie ($vel1,$vel12) atstāti brīvi katram gadījumam, ja nu ievajagas vēl kādu aili
		list($niks,$teksts,$datums,$ip,$url,$vel1,$vel12) = explode("|*|", $f[$i]);
		if ($teksts !== "" && $niks !== "") {
			//labojam komentāru numerāciju
			if ($sakt == "1") {
				$rinda = $cik-$i;
			} else {
				$rinda = $i+1;
			}
			$teksts = smaidi($teksts);
			//čeko, vai norādīta saite, ja ir, tad taisa linku
			if ($url != "" && $url != "http://" && $url != "nav") {
				$autors = "<a title=\"$niks mājaslapa\" href=\"$url\" target=\"_blank\">$niks</a>";
			} else {
				$autors = $niks;
			}
			//parāda, kas un kad pievienojis komentāru
			echo "	<tr>\n		<td class=\"komentars\"><span class=\"datums\"><b>#$rinda</b> Pievienoja $autors tālajā $datums</span><br /><span class=\"teksts\">$teksts</div></td>\n	</tr>\n";
		}
	}
	//izveido rūti priekš sadalījuma pa lapām
	echo "	<tr>\n		<td>";
	//izveido linku uz iepriekšējo lapu, ja nav pirmā lapa
	if ($komentarulapa>1) {
		//uztaisam linku uz iepriekšējo lapu
		$komentarulapa = $komentarulapa-1;
		echo "<a href=\"?komentarulapa=$komentarulapa\" class=\"komenti\"><</a>";
	}
	//saraksts ar lapām
	for ($i=1; $i<=$lapas; $i++) {
		echo "<a href=\"?komentarulapa=$i\" class=\"komenti\">$i</a>";
	}
	//nebeidz tabulas rūti
	echo "</td>\n	</tr>\n";
} else {
	//ievieš smaidiņus noklusētajā tekstā
	$navkom = smaidi($navkom);
	//parāda noklusēto tekstu
	echo "	<tr>\n		<td class=\"komentars\"><span class=\"teksts\">$navkom</span></td>\n	</tr>\n"; 
}
?>
	<tr>
		<th>Pievienot komentāru</th>
	</tr>	
	<tr>
		<td>
			<form name="komentars" action="?darbiba=komentars" method="post" onsubmit="return ParbauditFormu(this);">
				<span style="color:red;">*</span>Niks:<br />
				<input size="30" name="niks" type="text" value="<?php if (isset($_COOKIE['niks'])) { echo strip_tags($_COOKIE['niks']); } ?>" /><br />
				Url:<br />
				<input size="30" name="url" type="text" value="<?php if (isset($_COOKIE['url'])) { echo strip_tags($_COOKIE['url']); } else { echo "http://"; } ?>" /><br />
				<span style="color:red;">*</span>Teksts:<br />
				<textarea cols="40" rows="5" name="teksts"></textarea><br />
				<a href="javascript:IeliktSmaidu(':)')"><?php echo smaidi(":)"); ?></a> 
				<a href="javascript:IeliktSmaidu(';)')"><?php echo smaidi(";)"); ?></a> 
				<a href="javascript:IeliktSmaidu(':D')"><?php echo smaidi(":D"); ?></a> 
				<a href="javascript:IeliktSmaidu(':P')"><?php echo smaidi(":P"); ?></a> 
				<a href="javascript:IeliktSmaidu(':(')"><?php echo smaidi(":("); ?></a> 
				<a href="javascript:IeliktSmaidu('8)')"><?php echo smaidi("8)"); ?></a> 
				<a href="javascript:IeliktSmaidu('???')"><?php echo smaidi("???"); ?></a> 
				<a href="javascript:IeliktSmaidu('!!!')"><?php echo smaidi("!!!"); ?></a> 
				<a href="javascript:IeliktSmaidu(':|')"><?php echo smaidi(":|"); ?></a> 
				<a href="javascript:IeliktSmaidu('[b][/b]')"><img src="bildes/bold.gif" width="15" height="15" border="0" alt="B" /></a> 
				<a href="javascript:IeliktSmaidu('[i][/i]')"><img src="bildes/italic.gif" width="15" height="15" border="0" alt="I" /></a> 
				<a href="javascript:IeliktSmaidu('[u][/u]')"><img src="bildes/underline.gif" width="15" height="15" border="0" alt="U" /></a><br />				
<?php if ($captcha == "1") { ?>
				<span style="color:red;">*</span>Pārbaudes kods: 
				<img src="captcha.php" alt="security image" border="0"/><br />
				<input type="text" name="secure" size="30"><br />
<?php } if ($detrkonf == "1") { ?>
				<input name="detrans" type="checkbox" value="1" id="detrans" /><label for="detrans">detranslitēt</label><br />
<?php } ?>
				<input value="Pievienot" type="submit" />
				<br />
				<br />
			</form>
		</td>
	</tr>
	<tr>
		<th>&copy; <?php $now = date("Y"); if ($now == "2008") { echo "2008"; } else { echo "2008 - $now"; } echo ", $nosaukums"; ?></th>
	</tr>
</table>
</body>

</html>