<?php 
/*
VG 0.2.2 Captcha

Copyright (C) 2007 Madars Anzi�is

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

######### KONFIGUR�CIJA #################################

$bilde = ImageCreateFromjpeg("bildes/captcha.jpg"); //fona att�ls
$length = 5; //simbolu skaits
$font = 3; //fonts
$x=imagesx($bilde)-46; //teksta atra�an�s vieta (x ass)
$y=imagesy($bilde)-14; //teksta atra�an�s vieta (y ass) 
$tekstakrasa = imagecolorallocate ($bilde, 75, 75, 75); //teksta kr�sa


#########################################################

//s�k sesiju
session_start();

$text = "";
//simboli kurus izmantot. Izv�kts O/0 un I/1, jo tos viegli sajaukt
$key_chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
$rand_max  = strlen($key_chars) - 1;
for ($i = 0; $i < $length; $i++) {
    $rand_pos  = rand(0, $rand_max);
    $text.= $key_chars{$rand_pos};
}

//ieliek tekstu sesij�
$_SESSION['captcha'] = $text;

//apdruk� un padod bildi ar tekstu
imagestring($bilde, $font, $x, $y,  $text, $tekstakrasa);
header("Content-type: image/pjpeg");
imagejpeg($bilde);
?>