<?php
/*
~~~~~~~~ WapLapa ~~~~~~~

Copyright (C) 2007 Madars Anziķis

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

Versija: 1.0
Modificēts: 2007.11.18.
Mail: mad182@gmail.com
Info: http://www.ppf.lu.lv/mad182/?lapa=lasit&raksts=4
*/

######################### KONFUGURĀCIJA ########################

/* Lapas nosaukums */
$nosaukums = "Forša lapa"; 

/* Ievadteksts (teksta gabals, kas parādīsies atverot pirmo lapu) */
$teksts = "Laipni lūgtum manā foršajā lapā. Velc uz nebēdu!";

/* Norādi, vai parādot lapu izmantot XHTML vai WML. XHTML priekšrocība ir, 
ka to var parādit arī jebkurš datora WEB pārlūks un ar to nav problēmu uz 
lielākās daļas moderno telefonu. Savukārt WML atbalsta vecāki telefoni. Izvēle
tavās rokās. "wml", lai izmantotu wml, jebkas cits ieslēgs xhtml */
$variants = "xhtml"; 

/* Mapes, nu kurām tiks nolasīti faili un attiecīgo lapu nosaukumi. Šīs mapes var 
pievienot cik nepieciešams, jāieraksta tikai nākamais skaitlis kvadrātiekavās (0,1,2,3,4...).
Īstajam mapes nosaukumam ($mape[x]) nevajadzētu saturēt garumzīmes un atstarpes,
bet teksts, kas parādīsies lapā ($sauc[x]) var būt jebkāds. */
//pirmā mape
$mape[0] = "bildes"; 
$sauc[0] = "Attēli";
//otrā mape
$mape[1] = "speles";
$sauc[1] = "Spēles";
//un tā tālāk
$mape[2] = "melodijas";
$sauc[2] = "Zvana melodijas";

/* Cik failus parādīt vienā lapā */
$lapaa = "10";

/* Teksti, kas parādās lapā */
$txt['faili'] = "Faili";
$txt['sakums'] = "Sākums";
$txt['tuks'] = "Šajā sadaļā šobrīd nav failu.";
$txt['iepr'] = "Atpakaļ";
$txt['nakam'] = "Nākamā";


############# TĀLĀK REDIĢĒ, TIKAI JA ZINI, KO DARI! ############

//FUNKCIJAS

//izdrukā lapas sākumu, atkarībā, vai izvēlēts xhtml vai wml
function augsa($variants,$lappuse) {
	if ($variants == "wml") {
		header("Content-type: text/vnd.wap.wml"); 
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"; 
		echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\""." \"http://www.wapforum.org/DTD/wml_1.1.xml\">"; 
		echo "<wml>\n<card id=\"card1\" title=\"$lappuse\">\n";
	} else {
		echo "<!DOCTYPE html\nPUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">\n";
		echo "<head>\n<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\" />\n<title>$lappuse</title>\n</head>\n<body>\n";
	}
}

//pārvērš faila izmērus saprotamākā veidā
function izmeri($izmers) {
	if(!($izmers <= 0)){
		$apzime = array(" b", " kb", " mb", " gb", " tb");
		return round($izmers/pow(1024, ($i = floor(log($izmers, 1024)))), 2) . $apzime[$i];
	} else {
		return "0 b";
	}
}

//LAPA

//nosaka kura sadaļa ir pieprasīta un vai tāda eksistē, ja viss OK, parāda
if (isset($_GET['lapa']) && array_search($_GET['lapa'],$mape) !== FALSE) { 
	$lapa = $_GET['lapa'];
	$nosaukums = $sauc[array_search($lapa,$mape)];
	if (!$nosaukums) {
		$nosaukums = $txt['faili'];
	}
	//padod lapas sākumdaļu, headerus utt.
	augsa($variants,$nosaukums);
	echo "	<p>\n";
	if ($variants == "wml") {
		echo "		<do type=\"option\" label=\"".$txt['sakums']."\"><go href=\"".$_SERVER['PHP_SELF']."\"/></do>\n";
	}
	echo "		<a href=\"".$_SERVER['PHP_SELF']."\">".$txt['sakums']."</a><br />\n";
	echo "		<b>$nosaukums</b><br/>\n";
	$nolasit = opendir("$lapa");
	//ielasa visus failus masīvā
	$masivs = array(); 
	while (($file = readdir($nolasit))!==false) {
		if ($file != "." && $file != ".." && $file != "index.php" && $file != "index.htm" && $file != "index.html") {
			$masivs[] = $file;
		}
	}
	//sakārto pēc alfabēta un saskaita failus
	sort($masivs);
	$skaits = count($masivs);
	//čeko, vai masīvs nav tukšs
	if ($skaits > 0) {
		//noskaidro, kuru lpp. jārāda un vai tāda eksistē
		$lapuskaits = ceil($skaits/$lapaa);
		if (isset($_GET['lpp']) && $_GET['lpp'] < $lapuskaits && $_GET['lpp'] >= 0) {
			$lpp = $_GET['lpp'];
		} else {
			$lpp = 0;
		}
		//sarēķina, kurus failus jārāda
		$pirmais = $lpp*$lapaa;
		$pedejais = $pirmais+$lapaa;
		//dabū nosaukumus un numuru no masīva
		while (list($numurs, $fails) = each($masivs)) {
			//parāda pieprasītos failus
			if (($numurs >= $pirmais) && ($numurs < $pedejais)) {
				$izmers = izmeri(filesize("$lapa/$fails"));
				//wml variants
				if ($variants == "wml") {
					echo "		<a href=\"$lapa/$fails\">$fails</a> $izmers<br />\n";
				//xhtml variants
				} else {
					$tips  = substr("$fails", -4);
					//bildēm parāda arī platumu un augstumu
					if ($tips == ".jpg" or $tips == "jpeg" or $tips == ".gif" or $tips == ".png" or $tips == ".bmp" or $tips == "wbmp") {
						list($platums, $augstums) = getimagesize("$lapa/$fails");
						echo "		<a href=\"$lapa/$fails\">$fails</a> [$izmers - ".$platums."x".$augstums."]<br />\n";
					} else {
						echo "		<a href=\"$lapa/$fails\">$fails</a> [$izmers]<br />\n";
					}
				}
			}
		}
		//ja lpp nav pirmā, parāda linku uz iepriekšējo
		if ($lpp > 0) {
			$iepr = $lpp-1;
			echo "		<a href=\"?lapa=$lapa&amp;lpp=$iepr\">".$txt['iepr']."</a> \n";
		}
		//ja lpp nav pēdējā, parāda linku uz nākamo
		if ($pedejais < $skaits) {
			$nak = $lpp+1;
			echo "		<a href=\"?lapa=$lapa&amp;lpp=$nak\">".$txt['nakam']."</a>\n";
		}
	} else {
		echo "		".$txt['tuks']."\n";
	}
	closedir($nolasit);
	echo "	</p>\n";
//ja pieprasīta sākumlapa vai kaut kas nepareizs, parāda sākumlapu
} else {
	augsa($variants,$nosaukums);
	echo "	<p>\n";
	//čeko vai norādīts lapas nosaukums un teksts, ja ir, izdrukā
	if ($nosaukums) {
		echo "		<b>$nosaukums</b><br/>\n";
	}
	if ($teksts) {
		echo "		$teksts<br/>\n"; 
	} 
	echo "	</p>\n	<p>\n		<b>".$txt['faili'].":</b><br/>\n";
	//uzzina, cik mapes un iet cauri sarakstam
	for ($i=0; $i<sizeof($mape); $i++) { 
		//pārbauda vai ir mape, un ja ir, tad parāda linku uz attiecīgo lapu
		if (is_dir($mape[$i])) {
			echo "		<a href=\"?lapa=$mape[$i]\">$sauc[$i]</a><br/>\n";
		} else {
			//ja mapes nav, mēģina to izveidot
			mkdir($mape[$i]);
			//čeko, vai tagad ir mape
			if (is_dir($mape[$i])) {
				echo "		<a href=\"?lapa=$mape[$i]\">$sauc[$i]</a> (izveidota)<br/>\n";
			} else {
				echo "		Konfigurācijā minēta mape $mape[$i], taču tā netika atrasta un to neizdevās izveidot.<br/>\n";
			}
		}
	}
	echo "	</p>\n";
}
//parāda lapas noslēgumu
if ($variants == "wml") {
	echo "</card>\n</wml>";
} else {
	echo "</body>\n</html>";
}
?>